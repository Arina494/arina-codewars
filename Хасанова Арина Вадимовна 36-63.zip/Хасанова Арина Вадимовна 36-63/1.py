user_input = input("Введите число: ")
print(f"Введено: {user_input}, тип: {type(user_input).__name__}")

number = int(user_input)
print(f"Число: {number}, тип после преобразования: {type(number).__name__}")

user_str = str(number)
print(f"Строка: {user_str}, тип: {type(user_str).__name__}")