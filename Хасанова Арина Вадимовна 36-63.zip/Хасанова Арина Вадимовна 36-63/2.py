a = int(input("Введите число: "))

if a > 0:
    print(0-a)
else:
    print(a)